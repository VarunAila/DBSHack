function validate(){
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if(username="kar123" && password=="kar123"){
        alert("login sucessfull");
        window.location="success.html";
        return false;
    }
    else{
        alert("Incorrect usename or password")
    }
}